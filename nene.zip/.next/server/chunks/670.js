exports.id = 670;
exports.ids = [670];
exports.modules = {

/***/ 3799:
/***/ ((module) => {

// Exports
module.exports = {
	"gridContainer": "Otro_gridContainer__JJjCW",
	"gridContainerC": "Otro_gridContainerC__kaGMa",
	"gridContainerF": "Otro_gridContainerF__UI3lT",
	"item1": "Otro_item1__8bmhX",
	"itemF": "Otro_itemF___Ubh6",
	"descriptionItem": "Otro_descriptionItem__43_ox",
	"descriptionItemC": "Otro_descriptionItemC__cUW3v",
	"logoItem": "Otro_logoItem__l7sOs",
	"containerSeccion": "Otro_containerSeccion__7g5zL",
	"containerSeccion2": "Otro_containerSeccion2__0Boa1",
	"descriptionSeccion": "Otro_descriptionSeccion__GOxst",
	"encabezado": "Otro_encabezado__pkq6L",
	"li": "Otro_li__O5The",
	"logo": "Otro_logo__FXHl_",
	"imagenAgua": "Otro_imagenAgua__Vfmcj",
	"navContainer": "Otro_navContainer__WNVl7",
	"nav": "Otro_nav__xR3Kn",
	"a": "Otro_a__Rjnbe",
	"card": "Otro_card__jcUTK",
	"footer": "Otro_footer__TIQXm",
	"code": "Otro_code__u6Rgb"
};


/***/ }),

/***/ 7127:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3799);
/* harmony import */ var _styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4__);





const Footer = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().gridContainerF),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().itemF),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    src: "/img/coop.png",
                    height: 100,
                    width: 200,
                    alt: "logo coop",
                    className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().logo)
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().itemF),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/politicas",
                            target: "_blank",
                            rel: "noreferrer",
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().a),
                            children: "POLITICA DE PRIVACIDAD"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/declaracion",
                            target: "_blank",
                            rel: "noreferrer",
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().a),
                            children: "DECLARACI\xd3N DE ACCESIBILIDAD"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "#",
                            target: "_blank",
                            rel: "noreferrer",
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().a),
                            children: "T\xc9RMINOS LEGALES"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().itemF),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "COOPERATIVA DE SERVICIOS CIBV LTDA."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "(En proceso de Constituci\xf3n)"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Las Palmas 385, Locales 3 y 4"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Pe\xf1alol\xe9n, Santiago de Chile."
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().itemF),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: "#",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: "/img/Facebook_W.png",
                            height: 30,
                            width: 30,
                            alt: "facebook",
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().logo)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: "#",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: "/img/Twitter_W.png",
                            height: 30,
                            width: 30,
                            alt: "twitter",
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().logo)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: "#",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: "/img/Instagram_W.png",
                            height: 30,
                            width: 30,
                            alt: "instagram",
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().logo)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: "#",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: "/img/Linkedin_W.png",
                            height: 30,
                            width: 30,
                            alt: "linkedin",
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().logo)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: "#",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: "/img/Whatsapp_W.png",
                            height: 30,
                            width: 30,
                            alt: "whatsapp",
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_4___default().logo)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "@ 2022 Todos los derechos reservados Cooperativa de Servicios CIBV Ltda."
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 2787:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ Navbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_scroll_modules__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7163);
/* harmony import */ var react_scroll_modules__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_scroll_modules__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3799);
/* harmony import */ var _styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5__);






const Navbar = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().gridContainerC),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().nav),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().ul),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().li),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().a),
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: "/img/logocibv.png",
                                height: 200,
                                width: 200,
                                alt: "CIBV",
                                className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().logo)
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().li),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_scroll_modules__WEBPACK_IMPORTED_MODULE_2__.Link, {
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().a),
                            to: "cibv",
                            spy: true,
                            smooth: true,
                            offset: 50,
                            duration: 500,
                            children: "Nosotros"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().li),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_scroll_modules__WEBPACK_IMPORTED_MODULE_2__.Link, {
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().a),
                            to: "capitales",
                            spy: true,
                            smooth: true,
                            offset: 50,
                            duration: 500,
                            children: "Indicadores"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().li),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_scroll_modules__WEBPACK_IMPORTED_MODULE_2__.Link, {
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().a),
                            to: "intereses",
                            spy: true,
                            smooth: true,
                            offset: 50,
                            duration: 500,
                            children: "Inversiones"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().li),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().a),
                            href: "#",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: "/img/Facebook_W.png",
                                height: 30,
                                width: 30,
                                alt: "facebook",
                                className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().logo)
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().li),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().a),
                            href: "#",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: "/img/Twitter_W.png",
                                height: 30,
                                width: 30,
                                alt: "twitter",
                                className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().logo)
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().li),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().a),
                            href: "#",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: "/img/Instagram_W.png",
                                height: 30,
                                width: 30,
                                alt: "instagram",
                                className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().logo)
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().li),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().a),
                            href: "#",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: "/img/Linkedin_W.png",
                                height: 30,
                                width: 30,
                                alt: "linkedin",
                                className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().logo)
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().li),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().a),
                            href: "#",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: "/img/Whatsapp_W.png",
                                height: 30,
                                width: 30,
                                alt: "whatsapp",
                                className: (_styles_Otro_module_css__WEBPACK_IMPORTED_MODULE_5___default().logo)
                            })
                        })
                    })
                ]
            })
        })
    });
};


/***/ })

};
;